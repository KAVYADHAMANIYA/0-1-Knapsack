# Assignment: 0/1 Knapsack using Dynamic Programming (C)

**Name:** ____________________  **Roll No.:** ____________  **Date:** 25 Oct 2026

## 1. Aim
Read multiple test cases from a file, solve each with the 0/1 Knapsack dynamic
programming algorithm, write the results to `result.txt`, and display the DP
table being built step by step as ASCII output.

## 2. Input format
Test cases are separated by lines starting with `#Test`.
- First line of a case: `n W` (number of items, capacity)
- Next `n` lines: `weight value`

## 3. Algorithm
Let `dp[i][c]` be the maximum value using the first `i` items with capacity `c`.

```
dp[0][c] = 0                                   for all c
dp[i][c] = dp[i-1][c]                          if wt[i] > c
dp[i][c] = max( dp[i-1][c],                    (skip item i)
                dp[i-1][c - wt[i]] + val[i] )  otherwise (take item i)
answer   = dp[n][W]
```
Chosen items are recovered by backtracking from `dp[n][W]`: item `i` was taken
when `dp[i][c] != dp[i-1][c]`, after which `c -= wt[i]`.

**Time complexity:** O(n x W)  **Space complexity:** O(n x W)

## 4. Files
| File | Purpose |
|---|---|
| `knapsack.c` | Source code |
| `Makefile` | Build/run helper |
| `Knapsack_data.txt` | Input test cases |
| `result.txt` | Output, format `#Test<k> n W  result` |
| `visualization.txt` | Captured step-by-step DP tables for all tests |

## 5. How to compile and run
```
make              # or: gcc -std=c99 -O2 -o knapsack knapsack.c
./knapsack Knapsack_data.txt            # step-by-step tables, writes result.txt
./knapsack Knapsack_data.txt 400        # live animation, 400 ms per row
```

## 6. Results
| Test | n | W | Max value |
|---|---|---|---|
| 1 | 4 | 10 | 150 |
| 2 | 5 | 15 | 100 |
| 3 | 6 | 12 | 150 |
| 4 | 5 | 8 | 90 |
| 5 | 7 | 20 | 122 |
| 6 | 4 | 6 | 90 |
| 7 | 5 | 25 | 47 |
| 8 | 6 | 18 | 95 |
| 9 | 8 | 30 | 290 |
| 10 | 10 | 50 | 100 |

## 7. Sample visualization (Test 1)
```
        cap    0   1   2   3   4   5   6   7   8   9  10
  none    |   0   0   0   0   0   0   0   0   0   0   0
  w5,v60  |   0   0   0   0   0  60  60  60  60  60  60
  w3,v50  |   0   0   0  50  50  60  60  60 110 110 110
  w4,v70  |   0   0   0  50  70  70  70 120 120 130 130
->w2,v30  |   0   0  30  50  70  80 100 120 120 150 150
```
Items chosen: (2,30) (4,70) (3,50) -> weight 9, value 150.

## 8. Conclusion
The DP table avoids recomputing overlapping subproblems and gives the optimal
value in O(nW) time. Results were cross-checked against an independent Python
implementation and matched on all 10 test cases.
